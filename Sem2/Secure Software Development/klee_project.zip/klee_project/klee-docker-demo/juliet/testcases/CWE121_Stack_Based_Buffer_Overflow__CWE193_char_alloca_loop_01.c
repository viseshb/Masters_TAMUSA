#include <stdio.h>
#include <string.h>

// BAD: buffer too small (no room for '\0')
void bad_demo(const char *input) {
    char buf[10];
    buf[0] = '\0';
    // POTENTIAL OVERFLOW if input is longer than 9 chars
    strcpy(buf, input);
    printf("Bad result:  %s\n", buf);
}

// GOOD: buffer has space for 10 chars + the '\0'
void good_demo(const char *input) {
    char buf[10 + 1];
    buf[0] = '\0';
    // Safe as long as input is ≤10 chars
    strcpy(buf, input);
    printf("Good result: %s\n", buf);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <string>\n", argv[0]);
        return 1;
    }
    const char *user_input = argv[1];

    printf("Calling bad_demo()...\n");
    bad_demo(user_input);

    printf("Calling good_demo()...\n");
    good_demo(user_input);

    return 0;
}
