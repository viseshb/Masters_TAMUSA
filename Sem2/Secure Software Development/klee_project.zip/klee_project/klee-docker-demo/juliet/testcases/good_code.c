#include <stdio.h>
#include <string.h>

#define MAX_LEN 10           /* max chars we want to copy */
#define BUF_SIZE (MAX_LEN + 1)  /* +1 for the terminating '\0' */

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <up to %d‑char string>\n", argv[0], MAX_LEN);
        return 1;
    }

    char buf[BUF_SIZE];

    /* Copy at most MAX_LEN chars, then force a NUL */
    strncpy(buf, argv[1], MAX_LEN);
    buf[MAX_LEN] = '\0';

    printf("You entered (safe): %s\n", buf);
    return 0;
}
