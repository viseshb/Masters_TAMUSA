#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <overflow_string>\n", argv[0]);
        return 1;
    }
    const char *input = argv[1];

    char buf_bad[10];        /* no room for '\0' */
    char buf_good[10 + 1];   /* room for '\0' */
    char *data;

    /* --- Bad case: if(1) --- */
    if (1) {
        /* FLAW: data → undersized buffer */
        data = buf_bad;
    } else {
        /* dead code */
        data = buf_good;
    }
    data[0] = '\0';
    /* POTENTIAL OVERFLOW: copies strlen(input)+1 bytes into a 10‑byte buffer */
    strcpy(data, input);
    printf("Bad result:    %s\n", data);

    /* --- GoodG2B1: if(0)/else --- */
    if (0) {
        /* dead code */
        data = buf_bad;
    } else {
        /* FIX: data → properly sized buffer */
        data = buf_good;
    }
    data[0] = '\0';
    strcpy(data, input);  /* safe if input ≤10 chars */
    printf("GoodG2B1 result: %s\n", data);

    /* --- GoodG2B2: if(1) --- */
    if (1) {
        /* FIX: data → properly sized buffer */
        data = buf_good;
    } else {
        /* dead code */
        data = buf_bad;
    }
    data[0] = '\0';
    strcpy(data, input);  /* safe if input ≤10 chars */
    printf("GoodG2B2 result: %s\n", data);

    return 0;
}
